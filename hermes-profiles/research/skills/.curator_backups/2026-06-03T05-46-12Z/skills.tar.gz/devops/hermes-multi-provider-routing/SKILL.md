---
name: hermes-multi-provider-routing
description: "Configurar Hermes con múltiples proveedores (cloud + local) usando perfiles separados para evitar saturar la PC y garantizar disponibilidad. Incluye lista de modelos gratuitos verificados, pitfalls de delegate_task y estrategia de fallback validada."
version: 1.0.0
author: OWL
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [hermes, multi-provider, ollama, openrouter, profiles, fallback, delegation]
---

# Hermes Multi-Provider Routing

Configurar Hermes para que use modelos cloud (OpenRouter) y locales (Ollama) de forma inteligente, sin saturar la PC.

## Concepto clave

- **Perfil principal** (default): modelo cloud gratuito para chat general
- **Perfil local** (ollama): modelo local para tareas pesadas de código
- **Nunca correr 2+ modelos locales en paralelo** → se satura la RAM
- **Los modelos gratuitos de OpenRouter tienen rate limits agresivos** → no confiar como único fallback

## Configuración del perfil Ollama

```bash
# 1. Crear perfil
hermes profile create ollama

# 2. Configurar modelo local
hermes -p ollama config set model.base_url "http://localhost:11434/v1"
hermes -p ollama config set model.default "qwen3.6:latest"
hermes -p ollama config set model.provider "ollama"
hermes -p ollama config set model.api_key "ollama-local"
```

## Usar el perfil Ollama para tareas de código

```bash
# Tarea simple
hermes -p ollama chat -q "Escribe una función Python que..."

# Tarea con archivo
hermes -p ollama chat -q "Revisa este código y sugiere mejoras" < archivo.py
```

## Delegación de subagentes

**IMPORTANTE:** `delegate_task` NO respeta `delegation.config` del config.yaml. Siempre usa el modelo del perfil activo.

Para delegar a un modelo específico, usar `hermes chat -q` directamente en vez de `delegate_task`:

```bash
# En vez de delegate_task (que ignora la config):
hermes -p ollama chat -q "Tarea de código compleja" &
```

## Modelos gratuitos de OpenRouter (verificar disponibilidad)

Los modelos `:free` tienen rate limits muy agresivos. Verificar antes de usar:

```bash
# Probar disponibilidad
curl -s -X POST "https://openrouter.ai/api/v1/chat/completions" \
  -H "Authorization: Bearer $OPENROUTER_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"qwen/qwen3-coder:free","messages":[{"role":"user","content":"hola"}],"max_tokens":10}'
```

Si da error 429 → rate limited, usar otro modelo o esperar.

## Fallback strategy

1. **Principal:** owl-alpha (OpenRouter) — chat general
2. **Si owl falla:** usar perfil ollama (`hermes -p ollama chat -q`)
3. **Si Ollama no está corriendo:** usar modelos gratuitos online (con rate limit)
4. **Último recurso:** modelos locales uno por vez en serie

## Estrategia recomendada (validada 2026-06-02)

1. **Principal (cloud):** `openrouter/owl-alpha` — NO cambiar, es el estable
2. **Código pesado:** `hermes -p ollama chat -q "..."` (qwen3.6 local) — no toca RAM del principal
3. **Subagentes en paralelo:** usar modelos cloud gratuitos (rate limit acceptable) en vez de locales
4. **Fallbacks Ollama (si OpenRouter cae):** uno por vez en serie, NUNCA en paralelo

## Modelos gratuitos OpenRouter verificados (2026-06-02)

Lista de modelos `:free` confirmados en OpenRouter. Todos tienen rate limit agresivo.

| Modelo | Contexto | Notas |
|--------|----------|-------|
| `openrouter/owl-alpha` | 1M | Estable, usar como principal |
| `qwen/qwen3-coder:free` | 1M | Mejor para código, pero rate limit muy agresivo (429 al primer uso) |
| `moonshotai/kimi-k2.6:free` | 262K | Potente, puede crashear (no usar como principal sin probar) |
| `google/gemma-4-31b-it:free` | 262K | General |
| `meta-llama/llama-3.3-70b-instruct:free` | 131K | General, sólido |
| `openai/gpt-oss-120b:free` | 131K | OpenAI |
| `z-ai/glm-4.5-air:free` | 131K | General |

**CUIDADO:** `openrouter/meta-llama/llama-3.3-70b-instruct:free` NO es un ID válido (error 400). El ID correcto es `meta-llama/llama-3.3-70b-instruct:free` (sin prefijo `openrouter/`).

## Pitfalls conocidos

- `delegate_task` ignora `delegation.config` y `delegation.model`/`delegation.provider` del config.yaml -> usar perfiles separados con `hermes -p ollama chat -q`
- `delegate_task` intenta usar `openrouter/meta-llama/llama-3.3-70b-instruct:free` (ID invalido) cuando falla -- este modelo NO existe con prefijo `openrouter/`
- No importa que pongas en `--provider ollama` en CLI, Hermes sigue mandando requests a la `base_url` del modelo principal (OpenRouter) -- hay que crear un PERFIL separado para que tenga su propia `base_url`
- Modelos `:free` de OpenRouter se rate-liman facilmente (429 incluso al primer uso)
- No cambiar el modelo principal en `config.yaml` sin probar primero -- si el nuevo modelo crashea, el gateway se cuelga y no salta el fallback automaticamente
- El fallback SOLO salta si OpenRouter como servicio entero cae -- no si un modelo individual crashea a mitad de respuesta
- Ollama debe estar corriendo para que el perfil ollama funcione
- No correr 2-3 modelos locales en paralelo -> se satura la RAM de la PC. Maximo 1 local a la vez, el resto online
- `openrouter/auto` y `openrouter/pareto-code` NO son gratis (precio variable/pago)
- Perfiles creados con `hermes profile create <nombre>` heredan skills del perfil default pero tienen config.yaml propio
- `hermes -p ollama chat -q` funciona correctamente con provider `custom` y modelo `qwen3.6:latest` cuando la base_url es `http://localhost:11434/v1`

## Estrategia recomendada (validada 2026-06-02)

1. **Principal (cloud):** `openrouter/owl-alpha` — NO cambiar, es el estable
2. **Código pesado:** `hermes -p ollama chat -q "..."` (qwen3.6 local) — no toca RAM del principal
3. **Subagentes en paralelo:** usar modelos cloud gratuitos (rate limit acceptable) en vez de locales
4. **Fallbacks Ollama (si OpenRouter cae):** uno por vez en serie, NUNCA en paralelo

## IDs de modelos válidos para profile create

Cuando se crea un perfil con `hermes -p ollama chat -q`, el modelo que responde es qwen3.6:latest (Ollama). Verificar con:

```bash
hermes -p ollama chat -q "decime tu modelo"
```

Si dice provider `custom` y modelo `qwen3.6:latest` → OK

## Config YAML Pitfalls (fix patterns)

### `hermes config set` serializa listas como strings — ROTO

Los campos `fallback_providers`, `model.fallbacks`, y las entradas dentro de `providers.*` DEBEN ser listas/dicts YAML reales. `hermes config set` los guarda como strings escapados y Hermes no los parsea.

**Sintoma:** los fallbacks no se ejecutan cuando el principal cae; Ollama no aparece en `/provider` o `/model` picker.

**Fix con Python yaml.dump:**

```python
import yaml
path = r'C:\Users\user\...\hermes-data\config.yaml'  # ajustar ruta
with open(path, 'r') as f:
    cfg = yaml.safe_load(f)

# Corregir fallback_providers (debe ser lista de dicts)
cfg['fallback_providers'] = [
    {"provider": "ollama", "model": "qwen3.6:latest", "base_url": "http://localhost:11434/v1"},
    {"provider": "ollama", "model": "mistral-nemo-12b:latest", "base_url": "http://localhost:11434/v1"},
]

# Corregir model.fallbacks (lo mismo)
cfg['model']['fallbacks'] = [
    {"provider": "ollama", "model": "qwen3.6:latest", "base_url": "http://localhost:11434/v1"},
]

# Corregir providers.ollama (debe ser dict, no string)
cfg['providers']['ollama'] = {
    "name": "Ollama",
    "base_url": "http://localhost:11434/v1",
    "api_key": "ollama-local",
    "api_mode": "chat_completions",
}

with open(path, 'w') as f:
    yaml.dump(cfg, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
```

### Ollama no aparece en el picker `/model` o `/provider`

El picker de Hermes lee de dos fuentes:
1. `custom_providers` (lista) -- providers personalizados
2. `providers` (dict) -- providers nombrados

Ambas deben tener entradas validas (dicts, no strings). `get_compatible_custom_providers()` ignora entries que no sean `isinstance(entry, dict)`.

**Fix:** ademas de arreglar `providers.ollama`, agregar entrada en `custom_providers`:

```python
cfg['custom_providers'] = cfg.get('custom_providers', [])
ollama_exists = any(
    isinstance(e, dict) and '11434' in str(e.get('base_url', ''))
    for e in cfg['custom_providers']
)
if not ollama_exists:
    cfg['custom_providers'].append({
        "name": "Ollama",
        "base_url": "http://localhost:11434/v1",
        "api_key": "ollama-local",
        "model": "qwen3.6:latest",
    })
```

**Verificar:** reiniciar gateway despues de cambiar config.yaml.

### Cambiar modelo principal temporalmente (ej: se acabaron creditos)

Si OpenRouter se queda sin creditos, cambiar `model.default` a un modelo local:

```python
cfg['model']['default'] = 'ollama/qwen3.6:latest'
cfg['model']['provider'] = 'ollama'
cfg['model']['base_url'] = 'http://localhost:11434/v1'
```

**Recordar restaurar** cuando vuelvan los creditos:
```python
cfg['model']['default'] = 'openrouter/owl-alpha'
cfg['model']['provider'] = 'openrouter'
cfg['model']['base_url'] = 'https://openrouter.ai/api/v1'
```

### Como verificar que los fallbacks son listas reales

```python
import yaml
with open(path, 'r') as f:
    cfg = yaml.safe_load(f)
print(type(cfg['fallback_providers']))  # debe ser <class 'list'>, NO <class 'str'>
print(type(cfg['model']['fallbacks']))  # lo mismo
print(type(cfg['providers']['ollama'])) # debe ser <class 'dict'>, NO <class 'str'>
```

## Referencias

- [openrouter-free-models.md](references/openrouter-free-models.md) — lista de modelos gratuitos verificados, IDs invalidos conocidos y recomendaciones de rate limit
- [ollama-profile-setup.md](references/ollama-profile-setup.md) — setup detallado del perfil ollama (template, no creado aún)
- [config-yaml-pitfalls.md](references/config-yaml-pitfalls.md) — detalle tecnico de los bugs de serializacion YAML y el flujo de resolucion de providers
