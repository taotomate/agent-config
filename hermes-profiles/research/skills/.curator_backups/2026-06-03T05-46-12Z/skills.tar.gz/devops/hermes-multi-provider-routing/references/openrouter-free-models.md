# OpenRouter Free Models (verificado 2026-06-02)

Lista de modelos gratuitos disponibles en OpenRouter (pricing.prompt = "0" AND pricing.completion = "0").

## Modelos gratuitos verificados

| Modelo ID | Contexto | Uso recomendado | Notas |
|-----------|----------|----------------|-------|
| `openrouter/owl-alpha` | 1,048,756 | PRINCIPAL | Estable, no cambiar |
| `qwen/qwen3-coder:free` | 1,048,576 | Código | Rate limit MUY agresivo (429 al primer uso) |
| `nvidia/nemotron-3-super-120b-a12b:free` | 1,000,000 | General potente | |
| `moonshotai/kimi-k2.6:free` | 262,144 | General | Puede crashear - NO usar como principal |
| `google/gemma-4-31b-it:free` | 262,144 | General | |
| `google/gemma-4-26b-a4b-it:free` | 262,144 | General | |
| `qwen/qwen3-next-80b-a3b-instruct:free` | 262,144 | General | |
| `meta-llama/llama-3.3-70b-instruct:free` | 131,072 | General | Sólido, confiable |
| `openai/gpt-oss-120b:free` | 131,072 | General | |
| `z-ai/glm-4.5-air:free` | 131,072 | General | |
| `nousresearch/hermes-3-llama-3.1-405b:free` | 131,072 | General | |

## IDs INVÁLIDOS (NO usar)

- `openrouter/meta-llama/llama-3.3-70b-instruct:free` — error 400
- `openrouter/qwen/qwen3-coder:free` — el correcto es `qwen/qwen3-coder:free`

## Modelos NO gratis

- `openrouter/auto` — precio variable (NO gratis)
- `openrouter/pareto-code` — precio variable (NO gratis)

## Rate Limits

Todos los `:free` tienen rate limits. Si recibís 429:
- Esperar retry_after_seconds
- Cambiar a otro gratuito
- O usar ollama local (UNO por vez, no paralelo)
